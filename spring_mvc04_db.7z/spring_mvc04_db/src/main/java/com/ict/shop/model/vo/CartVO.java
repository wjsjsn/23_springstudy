package com.ict.shop.model.vo;

public class CartVO {
	private String idx, p_num, p_name, p_price, p_su, m_id, p_saleprice;

	public String getP_saleprice() {
		return p_saleprice;
	}

	public void setP_saleprice(String p_saleprice) {
		this.p_saleprice = p_saleprice;
	}

	public String getIdx() {
		return idx;
	}
	
	public void setIdx(String idx) {
		this.idx = idx;
	}

	public String getP_num() {
		return p_num;
	}

	public void setP_num(String p_num) {
		this.p_num = p_num;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_price() {
		return p_price;
	}

	public void setP_price(String p_price) {
		this.p_price = p_price;
	}

	public String getP_su() {
		return p_su;
	}

	public void setP_su(String p_su) {
		this.p_su = p_su;
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
}
